<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram ('1759060598:AAEGVzenZCZQMSMooOojEt1zrpEHfwO0il8');

print_r ($tlg->sendDocument ([
	'chat_id' => 1401217416,
	'caption' => "Backup\n@DUBSMSBOT\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));